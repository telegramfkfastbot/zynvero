import express from "express";
import { query } from "../db.js";
import { telegramAuth } from "../middleware/telegramAuth.js";

const router=express.Router();

router.get("/packages",async(req,res)=>{
  const r=await query(`SELECT * FROM packages WHERE active=true ORDER BY price ASC`);
  res.json({success:true,packages:r.rows});
});

router.post("/packages/:id/purchase",telegramAuth,async(req,res)=>{
  const client=await (await import("../db.js")).pool.connect();
  try{
    await client.query("BEGIN");
    const u=(await client.query(`SELECT * FROM users WHERE id=$1 FOR UPDATE`,[req.dbUser.id])).rows[0];
    const p=(await client.query(`SELECT * FROM packages WHERE id=$1 AND active=true`,[req.params.id])).rows[0];
    if(!p) throw new Error("Package not available");

    const price=Number(p.price);
    let bonus=Number(u.bonus_balance);
    let main=Number(u.main_balance);
    let bonusUsed=0, mainUsed=0;

    if(p.bonus_eligible && bonus>0){
      bonusUsed=Math.min(bonus,price);
    }
    mainUsed=price-bonusUsed;
    if(mainUsed>main) throw new Error("Insufficient balance");

    const expires=new Date(Date.now()+Number(p.duration_days)*86400000);

    await client.query(`UPDATE users SET bonus_balance=bonus_balance-$1, main_balance=main_balance-$2, updated_at=now() WHERE id=$3`,
      [bonusUsed,mainUsed,u.id]);

    const up=await client.query(`
      INSERT INTO user_packages(user_id,package_id,price_paid,payment_source,started_at,expires_at,status)
      VALUES($1,$2,$3,$4,now(),$5,'active') RETURNING *
    `,[u.id,p.id,price,bonusUsed>0&&mainUsed>0?"bonus+main":"main",expires]);

    await client.query(`
      INSERT INTO transactions(user_id,type,amount,description,idempotency_key)
      VALUES($1,'package_purchase',$2,$3,$4)
    `,[u.id,-price,`Package ${p.name}`,`purchase:${up.rows[0].id}`]);

    await client.query("COMMIT");
    res.json({success:true,user_package:up.rows[0],bonus_used:bonusUsed,main_used:mainUsed});
  }catch(e){
    await client.query("ROLLBACK");
    res.status(400).json({success:false,error:e.message});
  }finally{client.release();}
});

export default router;
