import express from "express";
import { query } from "../db.js";

const router = express.Router();

router.get("/config", async (req,res) => {
  const r = await query(`
    SELECT key,value FROM app_settings
    WHERE key IN ('maintenance_mode','default_language','signup_bonus')
  `);
  const settings = Object.fromEntries(r.rows.map(x=>[x.key,x.value]));
  const chats = await query(`
    SELECT name,username,url,chat_id,required
    FROM telegram_communities WHERE active=true ORDER BY sort_order,id
  `);
  res.json({
    success:true,
    maintenance_mode: settings.maintenance_mode === "true",
    default_language: settings.default_language || "en-US",
    signup_bonus: Number(settings.signup_bonus || 3),
    requiredChats: chats.rows.filter(x=>x.required),
    optionalChats: chats.rows.filter(x=>!x.required)
  });
});

router.get("/communities", async (req,res)=>{
  const r=await query(`SELECT name,username,url,chat_id,required FROM telegram_communities WHERE active=true ORDER BY sort_order,id`);
  res.json({success:true,communities:r.rows});
});

export default router;
