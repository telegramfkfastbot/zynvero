import express from "express";
import { query } from "../db.js";
import { verifyTelegramInitData } from "../middleware/telegramAuth.js";

const router = express.Router();

router.post("/auth", async (req,res) => {
  try {
    const initData = req.get("x-telegram-init-data") || "";
    const tg = await verifyTelegramInitData(initData);
    const telegramId = String(tg.id);

    const referral = String(req.body?.referral_code || "").trim() || null;

    let user = (await query("SELECT * FROM users WHERE telegram_id=$1", [telegramId])).rows[0];

    if (!user) {
      const code = `ZV${telegramId.slice(-8)}`;
      const signup = 3;
      const existingRef = referral
        ? (await query("SELECT id FROM users WHERE referral_code=$1", [referral])).rows[0]
        : null;

      const r = await query(`
        INSERT INTO users
        (telegram_id, username, first_name, last_name, main_balance, bonus_balance,
         signup_bonus, referral_code, referred_by, language, status)
        VALUES ($1,$2,$3,$4,0,$5,$5,$6,$7,'en-US','active')
        RETURNING *
      `, [
        telegramId, tg.username || null, tg.first_name || null, tg.last_name || null,
        signup, code, existingRef?.id || null
      ]);
      user = r.rows[0];

      await query(`
        INSERT INTO transactions(user_id,type,amount,description,idempotency_key)
        VALUES($1,'signup_bonus',$2,'Signup bonus',$3)
        ON CONFLICT (idempotency_key) DO NOTHING
      `,[user.id, signup, `signup:${user.id}`]);
    } else {
      await query(`
        UPDATE users SET username=$2, first_name=$3, last_name=$4, updated_at=now()
        WHERE id=$1
      `,[user.id,tg.username||null,tg.first_name||null,tg.last_name||null]);
      user = (await query("SELECT * FROM users WHERE id=$1",[user.id])).rows[0];
    }

    res.json({success:true,user});
  } catch(e) {
    res.status(400).json({success:false,error:e.message});
  }
});

router.get("/me", async (req,res) => {
  const userId = req.dbUser.id;
  const r = await query("SELECT * FROM users WHERE id=$1",[userId]);
  res.json({success:true,user:r.rows[0]});
});

router.get("/referral", async (req,res) => {
  const r = await query(`
    SELECT referral_code FROM users WHERE id=$1
  `,[req.dbUser.id]);
  const code = r.rows[0]?.referral_code || "";
  res.json({
    success:true,
    referral_code:code,
    referral_link: code ? `https://t.me/ZynveroCryptobot?start=${code}` : ""
  });
});

export default router;
