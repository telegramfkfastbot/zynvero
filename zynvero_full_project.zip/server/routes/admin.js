import express from "express";
import { query } from "../db.js";
import { adminAuth } from "../middleware/adminAuth.js";

const router = express.Router();
router.use(adminAuth);

router.get("/me",(req,res)=>res.json({success:true,admin:true,telegram_id:String(req.tgUser.id)}));

router.get("/users",async(req,res)=>{
  const r=await query(`SELECT id,telegram_id,username,first_name,last_name,main_balance,bonus_balance,language,status,created_at FROM users ORDER BY created_at DESC LIMIT 200`);
  res.json({success:true,users:r.rows});
});

router.get("/settings",async(req,res)=>{
  const r=await query(`SELECT key,value FROM app_settings ORDER BY key`);
  res.json({success:true,settings:r.rows});
});

router.put("/settings/:key",async(req,res)=>{
  const key=String(req.params.key);
  const value=String(req.body?.value ?? "");
  await query(`
    INSERT INTO app_settings(key,value) VALUES($1,$2)
    ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value, updated_at=now()
  `,[key,value]);
  res.json({success:true});
});

router.get("/communities",async(req,res)=>{
  const r=await query(`SELECT * FROM telegram_communities ORDER BY sort_order,id`);
  res.json({success:true,communities:r.rows});
});

router.get("/packages",async(req,res)=>{
  const r=await query(`SELECT * FROM packages ORDER BY created_at DESC`);
  res.json({success:true,packages:r.rows});
});

router.post("/packages",async(req,res)=>{
  const b=req.body||{};
  const r=await query(`
    INSERT INTO packages(name,description,price,duration_days,daily_reward,daily_reward_type,bonus_eligible,image_url,active)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *
  `,[
    b.name||"Untitled",b.description||"",b.price||0,b.duration_days||1,
    b.daily_reward||0,b.daily_reward_type||"fixed",b.bonus_eligible!==false,
    b.image_url||"",b.active!==false
  ]);
  res.json({success:true,package:r.rows[0]});
});

router.put("/packages/:id",async(req,res)=>{
  const b=req.body||{};
  const r=await query(`
    UPDATE packages SET
      name=COALESCE($2,name), description=COALESCE($3,description),
      price=COALESCE($4,price), duration_days=COALESCE($5,duration_days),
      daily_reward=COALESCE($6,daily_reward), daily_reward_type=COALESCE($7,daily_reward_type),
      bonus_eligible=COALESCE($8,bonus_eligible), image_url=COALESCE($9,image_url),
      active=COALESCE($10,active), updated_at=now()
    WHERE id=$1 RETURNING *
  `,[req.params.id,b.name,b.description,b.price,b.duration_days,b.daily_reward,b.daily_reward_type,b.bonus_eligible,b.image_url,b.active]);
  res.json({success:true,package:r.rows[0]});
});

export default router;
