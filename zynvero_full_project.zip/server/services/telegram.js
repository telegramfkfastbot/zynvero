export async function sendTelegramMessage(chatId, text) {
  if (!process.env.BOT_TOKEN || !chatId) return;
  const url = `https://api.telegram.org/bot${process.env.BOT_TOKEN}/sendMessage`;
  await fetch(url, {
    method: "POST",
    headers: {"content-type":"application/json"},
    body: JSON.stringify({chat_id: chatId, text, parse_mode:"HTML"})
  });
}
