import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import auth from "./routes/auth.js";
import config from "./routes/config.js";
import packages from "./routes/packages.js";
import admin from "./routes/admin.js";

dotenv.config();

const app=express();
const __filename=fileURLToPath(import.meta.url);
const __dirname=path.dirname(__filename);

app.use(express.json({limit:"1mb"}));
app.use(express.urlencoded({extended:false}));

app.get("/api/health",(req,res)=>res.json({success:true,service:"ZYNVERO"}));

app.use("/api",auth);
app.use("/api",config);
app.use("/api",packages);
app.use("/api/admin",admin);

app.use(express.static(path.join(__dirname,"../web")));

app.get("*",(req,res)=>{
  res.sendFile(path.join(__dirname,"../web/index.html"));
});

const port=Number(process.env.PORT||10000);
app.listen(port,()=>console.log(`ZYNVERO running on ${port}`));
