import crypto from "crypto";
import { query } from "../db.js";

function parseInitData(initData) {
  const params = new URLSearchParams(initData);
  const data = {};
  for (const [key, value] of params.entries()) data[key] = value;
  return data;
}

export async function verifyTelegramInitData(initData) {
  if (!initData || !process.env.BOT_TOKEN) throw new Error("Telegram authentication unavailable");

  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) throw new Error("Invalid Telegram initData");

  params.delete("hash");
  const pairs = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([k, v]) => `${k}=${v}`)
    .join("\n");

  const secret = crypto
    .createHmac("sha256", "WebAppData")
    .update(process.env.BOT_TOKEN)
    .digest();

  const expected = crypto
    .createHmac("sha256", secret)
    .update(pairs)
    .digest("hex");

  if (!crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(hash))) {
    throw new Error("Invalid Telegram signature");
  }

  const authDate = Number(params.get("auth_date") || 0);
  if (!authDate || Date.now()/1000 - authDate > 86400) {
    throw new Error("Telegram authentication expired");
  }

  const rawUser = params.get("user");
  if (!rawUser) throw new Error("Telegram user missing");

  return JSON.parse(rawUser);
}

export async function telegramAuth(req, res, next) {
  try {
    const initData = req.get("x-telegram-init-data") || req.get("X-Telegram-Init-Data");
    const tgUser = await verifyTelegramInitData(initData);
    const result = await query(
      `SELECT * FROM users WHERE telegram_id=$1 LIMIT 1`,
      [String(tgUser.id)]
    );
    if (!result.rows[0]) {
      return res.status(401).json({ success:false, error:"User not registered" });
    }
    req.tgUser = tgUser;
    req.dbUser = result.rows[0];
    next();
  } catch (e) {
    res.status(401).json({ success:false, error:e.message });
  }
}
