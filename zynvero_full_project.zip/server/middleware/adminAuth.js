import { query } from "../db.js";
import { telegramAuth } from "./telegramAuth.js";

export async function adminAuth(req, res, next) {
  await telegramAuth(req, res, async () => {
    const id = String(req.tgUser.id);
    if (id !== String(process.env.ADMIN_TELEGRAM_ID || "5624401046")) {
      return res.status(403).json({success:false,error:"Admin access required"});
    }
    req.isAdmin = true;
    next();
  });
}
