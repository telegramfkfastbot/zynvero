CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  telegram_id text UNIQUE NOT NULL,
  username text,
  first_name text,
  last_name text,
  main_balance numeric(18,2) NOT NULL DEFAULT 0,
  bonus_balance numeric(18,2) NOT NULL DEFAULT 0,
  signup_bonus numeric(18,2) NOT NULL DEFAULT 3,
  referral_code text UNIQUE,
  referred_by uuid REFERENCES users(id),
  language text NOT NULL DEFAULT 'en-US',
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS app_settings (
  key text PRIMARY KEY,
  value text NOT NULL DEFAULT '',
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS telegram_communities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  username text,
  url text NOT NULL,
  chat_id text NOT NULL,
  required boolean NOT NULL DEFAULT true,
  active boolean NOT NULL DEFAULT true,
  sort_order integer NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text DEFAULT '',
  price numeric(18,2) NOT NULL CHECK(price>=0),
  duration_days integer NOT NULL CHECK(duration_days>0),
  daily_reward numeric(18,2) NOT NULL DEFAULT 0 CHECK(daily_reward>=0),
  daily_reward_type text NOT NULL DEFAULT 'fixed',
  bonus_eligible boolean NOT NULL DEFAULT true,
  image_url text DEFAULT '',
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_packages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  package_id uuid NOT NULL REFERENCES packages(id),
  price_paid numeric(18,2) NOT NULL,
  payment_source text NOT NULL DEFAULT 'main',
  started_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type text NOT NULL,
  amount numeric(18,2) NOT NULL,
  description text DEFAULT '',
  idempotency_key text UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO app_settings(key,value) VALUES
('maintenance_mode','false'),
('default_language','en-US'),
('signup_bonus','3')
ON CONFLICT(key) DO NOTHING;

INSERT INTO telegram_communities(name,username,url,chat_id,required,sort_order)
VALUES
('ZYNVERO Announcement','@ZynveroCrypto','https://t.me/ZynveroCrypto','-1002094920926',true,1),
('ZYNVERO Ecosystem','@zynveroEcosystem','https://t.me/zynveroEcosystem','-1003976553960',true,2),
('ZYNVERO HelpDesk Group','@zynverohelpdesk','https://t.me/zynverohelpdesk','-1002057176093',true,3),
('ZYNVERO Crypto','@zynverocrypto','https://t.me/zynverocrypto','optional',false,4)
ON CONFLICT DO NOTHING;
