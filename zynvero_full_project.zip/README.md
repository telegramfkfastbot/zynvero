# ZYNVERO

Telegram Mini App + Bot foundation for ZYNVERO.

## Run
1. Copy `.env.example` to `.env`
2. Fill `DATABASE_URL`, `BOT_TOKEN`, `ADMIN_TELEGRAM_ID`
3. Run the SQL migrations in `server/migrations/`
4. Run `npm install`
5. Run `npm start`

Never commit `.env`.

## Supported locales
ru, es, en-US, en-GB, hi, ur, id, bn

## Required Telegram communities
- @ZynveroCrypto — -1002094920926
- @zynveroEcosystem — -1003976553960
- @zynverohelpdesk — -1002057176093
