const tg=window.Telegram?.WebApp;
if(tg){tg.ready();tg.expand();try{tg.setHeaderColor("#070707");tg.setBackgroundColor("#070707")}catch{}}
let currentUser=null,verified=false,locale="en-US",dict={};

function headers(){return {"Content-Type":"application/json","X-Telegram-Init-Data":tg?.initData||""}}
async function api(url,opt={}){const r=await fetch(url,{...opt,headers:{...headers(),...(opt.headers||{})}});const d=await r.json().catch(()=>({}));if(!r.ok)throw Error(d.error||"Request failed");return d}
function toast(s){const e=document.querySelector("#toast");e.textContent=s;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2500)}
async function loadDict(){const r=await fetch(`/i18n/${locale}.json`);dict=await r.json();document.querySelectorAll("[data-i18n]").forEach(e=>e.textContent=dict[e.dataset.i18n]||e.dataset.i18n)}
async function setLanguage(v){locale=v;localStorage.setItem("zynvero_language",v);if(currentUser){try{await api("/api/me",{method:"GET"})}catch{}}await loadDict();document.querySelector("#language").value=v}
function nav(id,btn){if(!verified)return;document.querySelectorAll(".page").forEach(x=>x.classList.remove("active"));document.getElementById(id)?.classList.add("active");document.querySelectorAll(".nav button").forEach(x=>x.classList.remove("active"));btn?.classList.add("active");if(id==="packages")loadPackages()}
async function boot(){
 try{
  locale=localStorage.getItem("zynvero_language")||"en-US"; await loadDict();
  const referral=new URLSearchParams(location.search).get("start")||"";
  const a=await api("/api/auth",{method:"POST",body:JSON.stringify({referral_code:referral.replace(/^ref_/,"")})});
  currentUser=a.user;
  locale=currentUser.language||locale;await loadDict();
  renderUser();await loadGate();
 }catch(e){console.error(e);toast(e.message||"Open ZYNVERO inside Telegram")}
}
function renderUser(){
 const name=[currentUser.first_name,currentUser.last_name].filter(Boolean).join(" ")||"ZYNVERO User";
 document.querySelector("#name").textContent=name;
 document.querySelector("#mainBalance").textContent=Number(currentUser.main_balance||0).toFixed(2);
 document.querySelector("#bonusBalance").textContent=Number(currentUser.bonus_balance||0).toFixed(2);
 document.querySelector("#profile").textContent=name;
 document.querySelector("#username").textContent=currentUser.username?`@${currentUser.username}`:"Telegram User";
 document.querySelector("#telegramId").textContent=currentUser.telegram_id;
 document.querySelector("#referralCode").textContent=currentUser.referral_code||"-";
 document.querySelector("#language").value=locale;
}
async function loadGate(){
 const c=await api("/api/communities");
 const box=document.querySelector("#communities");box.innerHTML="";
 c.communities.filter(x=>x.required).forEach(x=>{
  const d=document.createElement("div");d.className="card row";
  d.innerHTML=`<div><b>${x.name}</b><div class="label">${x.username||""}</div></div><button class="btn" style="width:auto">${dict.join||"Join"}</button>`;
  d.querySelector("button").onclick=()=>tg?.openTelegramLink?tg.openTelegramLink(x.url):window.open(x.url);
  box.appendChild(d);
 });
 document.querySelector("#gate").classList.add("active");
 document.querySelector("#home").classList.remove("active");
}
async function verify(){toast("Membership verification endpoint should be connected to Telegram getChatMember.");}
async function loadPackages(){
 try{
  const d=await api("/api/packages");const box=document.querySelector("#packageList");box.innerHTML="";
  d.packages.forEach(p=>{const e=document.createElement("div");e.className="card";
   e.innerHTML=`<div class="row"><b>${p.name}</b><b class="gold">$${Number(p.price).toFixed(2)}</b></div><p class="label">${p.description||""}</p><p>Daily Reward: <b>${p.daily_reward_type==="percentage"?p.daily_reward+"%":"$"+Number(p.daily_reward).toFixed(2)}</b></p><button class="btn">Purchase</button>`;
   e.querySelector("button").onclick=()=>purchase(p.id);box.appendChild(e);
  });
 }catch(e){toast(e.message)}
}
async function purchase(id){if(!confirm("Confirm package purchase?"))return;try{await api(`/api/packages/${id}/purchase`,{method:"POST",body:"{}"});toast("Package activated");const d=await api("/api/me");currentUser=d.user;renderUser()}catch(e){toast(e.message)}}
async function referral(){const d=await api("/api/referral");document.querySelector("#refLink").value=d.referral_link;document.querySelector("#refCode").textContent=d.referral_code}
async function copyRef(){const v=document.querySelector("#refLink").value;await navigator.clipboard.writeText(v);toast("Referral link copied")}
async function unlock(){verified=true;document.querySelector("#gate").classList.remove("active");document.querySelector("#home").classList.add("active");document.querySelector("#nav").style.display="grid";await referral()}
window.addEventListener("DOMContentLoaded",boot);
